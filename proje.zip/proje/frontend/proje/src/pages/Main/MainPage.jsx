import "./anasayfa.css"

const MainPage = () => {
  return (
    <div className="ekran">
        
    <header className="ekran-header">
        
        <nav className="navigation-main">
            <a href="/">Ana Sayfa</a>
            <a href="/madenler">Madenler</a>
            <a href="/istatistik">istatistikler</a>
            <a href="/haritalar">Haritalar</a>
            <a href="/tablolar">Tablolar</a>
            <a href="/uzman">Uzman Görüşü</a>
        </nav>
    </header>
       
    <div className="container-main">
        <div className="madenler-main">
            <div className="maden-main" data-maden="Altın">Altın</div>
            <div className="maden-main" data-maden="Bakır">Bakır</div>
            <div className="maden-main" data-maden="Çinko">Çinko</div>
            <div className="maden-main" data-maden="Gümüş">Gümüş</div>
        </div>

        <div className="detay-kutu-main">
            <h2 className="detay-baslik-main"></h2>
            <ul className="detay-liste-main">
                <li><span className="detay-etiket-main">Değer:</span> <span className="detay-deger-main"></span></li>
                <li><span className="detay-etiket-main">Renk:</span> <span className="detay-renk-main"></span></li>
            </ul>
        </div>
    </div>
    </div>
  )
}

export default MainPage
