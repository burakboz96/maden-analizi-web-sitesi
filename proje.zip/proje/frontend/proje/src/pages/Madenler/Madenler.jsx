import "./madenler.css"

const Madenler = () => {
  return (
    <div className="maden-sayfasi">
      

      <div className="maden-bilgisi">
        <div className="maden-icerik">
           <img src="resimler/WhatsApp Image 2023-12-18 at 11.43.38.jpeg" />
           <div className="content">
            <h1 className="maden-baslik">BOR</h1>
            <p className="maden-bilgi">Bor madeni, elementlerden biri olan borun doğal olarak oluşan cevherleridir. Doğada genellikle borat mineralleri ve boraks olarak bulunur. Bor, endüstriyel, tarımsal ve bilimsel birçok uygulamada kullanılır. bitki besin maddesi olarak, alev geciktirici özelliklere sahip olduğu için ahşap, tekstil ve polimer malzemelerin alev geciktirici özelliklerini artırmak için, yarıiletken özellikleri nedeniyle elektronik endüstrisinde kullanılır </p>
           </div> 
        </div>
    </div>

    <div className="maden-bilgisi">
        <div className="maden-icerik">
           <img src="resimler/bakır.jpeg" />
           <div className="content">
            <h1 className="maden-baslik">BAKIR</h1>
            <p className="maden-bilgi">Doğada genellikle bakır cevheri olarak bulunur ve eski çağlardan beri insanlar tarafından çeşitli amaçlar için kullanılmıştır. Bakır, termal ve elektriksel iletkenliği yüksek, yumuşak, kırmızımsı-kahverengi bir metaldir. Dayanıklılığı ve korozyon direnci nedeniyle inşaat ve yapı malzemelerinde kullanılır. </p>
           </div> 
        </div>
    </div>

    <div className="maden-bilgisi">
        <div className="maden-icerik">
           <img src="resimler/çinko.jpeg" />
           <div className="content">
            <h1 className="maden-baslik">ÇİNKO</h1>
            <p className="maden-bilgi"> Bu metal, doğada genellikle çinko cevherleri olarak bulunur ve birçok endüstriyel uygulama alanında kullanılır. Çinko, çeşitli pillerde anot olarak kullanılır. Özellikle çinko-karbon piller ve çinko-hava pilleri gibi piller çeşitli uygulamalarda yaygın olarak kullanılmaktadır.</p>
           </div> 
        </div>
    </div>

    <div className="maden-bilgisi">
        <div className="maden-icerik">
           <img src="resimler/demir.jpeg"/>
           <div className="content">
            <h1 className="maden-baslik">DEMİR</h1>
            <p className="maden-bilgi">Doğada geniş bir şekilde bulunur ve endüstri, inşaat, ulaşım ve birçok diğer sektörde yaygın olarak kullanılır.Demir, yüksek mukavemet ve dayanıklılık özelliklerine sahip bir metaldir. İnşaat sektöründe yapı malzemeleri, köprüler, gemiler gibi birçok alanda kullanılmasını sağlar. Hem yüzeyde hem de yer altında bulunan demir cevherleri, demirin çıkarılması için kullanılır.</p>
           </div> 
        </div>
    </div>

    <div className="maden-bilgisi">
        <div className="maden-icerik">
           <img src="resimler/gümüş.jpeg" />
           <div className="content">
            <h1 className="maden-baslik">GÜMÜŞ</h1>
            <p className="maden-bilgi">Doğada genellikle cevherler veya gümüş içeren mineraller halinde bulunur. Gümüş, yüksek iletkenlik özelliği, düşük reaktivite ve parlak gümüşi beyaz rengi nedeniyle çeşitli endüstriyel, elektronik, gıda, tıp ve dekoratif uygulamalarda kullanılan değerli bir metaldir.Gümüş, yüksek iletkenlik özelliği nedeniyle elektriksel bileşenlerde, özellikle de elektrik iletkenleri, kontaklar ve elektronik devrelerde, çeşitli cevherlerden çıkarılarak rafine edilir.</p>
           </div> 
        </div>
    </div>

    <div className="maden-bilgisi">
        <div className="maden-icerik">
           <img src="resimler/krom.jpeg" />
           <div className="content">
            <h1 className="maden-baslik">KROM</h1>
            <p className="maden-bilgi">Bu metal, gümüşi bir renge sahiptir ve dayanıklı, sert, parlak ve korozyona karşı dirençli özelliklere sahiptir. Krom, bir dizi endüstriyel uygulama alanında kullanılır ve aynı zamanda bazı bileşikleri biyolojik süreçlerde de rol oynar. Krom, çelik alaşımlarında kullanılarak malzemeye pas direnci kazandırır. Bu özellik, özellikle otomotiv endüstrisinde araç parçaları ve makineler için önemlidir.metal yüzeylerin kaplanması için kullanılarak estetik bir parlaklık ve korozyona karşı direnç sağlar.</p>
           </div> 
        </div>
    </div>
    </div>
  )
}

export default Madenler
