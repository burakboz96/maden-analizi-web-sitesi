import "./tablolar.css";

const Tablolar = () => {
  return (
    <>
    <div className="tablolar-sayfasi">
      <div id="ustKisim">Maden Analiz Bilgileri</div>
      <div id="beyazKisim">
        <div className="resimAlani">
          <img src="resimler/bor üretim.jpeg" alt="" />
        </div>
        <div className="textAlani">
          <p>
            Yıllara baktığımızda bor madeni üretimi kapasitesinin genel olarak
            hep bir artış halinde olduğunu söyleyebiliriz{" "}
          </p>
          <p>
            2019 ve 2021 yıllarında genel olarak bir artışın olduğunu ve sebebi
            ise cam ve seramik sanayide kullanıldığını söyleyebiliriz
          </p>
          <p>2023 yılı için veriler revize edilecektir.</p>
        </div>

        <div className="resimAlani">
          <img src="resimler/altın degeri.jpeg" alt="Resim 2" />
        </div>
        <div className="textAlani">
          <p>
            Altının sürekli olarak artış eğiliminde olması gerek ham maddesi
            hemde çıkarılımı konusunda çok fazla emek sarf edilmekte.{" "}
          </p>
          <p>
            Altın dünya çapında en güvenilir yatırım aracı olarak kullanılmakta
            buda fiyatların artmasını etkiliyor{" "}
          </p>
          <p>
            Güvenli liman olması sebebiyle yıllık cari bazda çok yüksek değerde
            ülkelere getiri sağlamakta.{" "}
          </p>
        </div>

        <div className="resimAlani">
          <img src="resimler/altın rezervi.jpeg" alt="Resim 1" />
        </div>
        <div className="textAlani">
          <p>Ülkeler bazlı altın dağılımı daire grafiğinde görülmektedir.</p>
          <p>
            Dağılımın genel olarak baktığımızda bir örüntüsü olmadağı karışık
            bir şekilde dağıldığı görülmektedir.
          </p>
          <p>
            Dağılımın çarpık ve girift olması geleceği hakkında bir tahmin
            sağlamıyor.
          </p>
        </div>

        <div className="resimAlani">
          <img src="resimler/dünya gümüş.jpeg" alt="Resim 1" />
        </div>
        <div className="textAlani">
          <p>
            Gümüş üretimine bakıldığında çok değerli ve sert bir maden olması
            gerek mücevher gerek diğer aletlerin ucu için çok çeşitli kullanımı
            vardır
          </p>
          <p>
            Yıl bazlı dünyada genel olarak bir artış eğiliminde olması büyük bir
            piyasa olduğunu gösteriyor.{" "}
          </p>
          <p>
            Genel olarak afrika kıtasında çıkarılıyor olması bu payda büyüktür.
          </p>
        </div>

        <div className="resimAlani">
          <img src="resimler/bakır cevheri.jpeg" alt="Resim 1" />
        </div>
        <div className="textAlani">
          <p>
            Bakır üretimi genel olarak belli bir skalada çıkarılmakta buda
            ülkenin ihtiyacını genel olarak karşılandığını gösteriyor{" "}
          </p>
          <p>
            Çok çeşitli kullanım alanı genel olarak kablolarda ve veri
            iletiminde kullanılmakta 1
          </p>
          <p>Çıkarımının azalacak olması öngörülmekte.</p>
        </div>

        <div className="resimAlani">
          <img src="resimler/ülkelere göre çinko rezervi.jpeg" alt="Resim 1" />
        </div>
        <div className="textAlani">
          <p>Çinkonun genel dağılımı ülkeler bazında bu şekildedir.</p>
          <p>Çinkonun genel dağılımında Çin zirvede görünüyor.</p>
        </div>

        <div className="resimAlani">
          <img src="resimler/demir üretimi.jpeg" alt="Resim 1" />
        </div>
        <div className="textAlani">
          <p>
            Demir üretimi her geçen yıl artmaktadır bunun sebebi çok çok çeşit
            kullanım alanıdır.
          </p>
          <p>Dünyanın her yerinde madeni bulunmakta buda bir diğer etken .</p>
          <p>Artışın daha fazla olacağı öngörülmektedir.</p>
        </div>

        <div className="resimAlani">
          <img src="resimler/krom ihracat ithalat.jpeg" alt="Resim 1" />
        </div>
        <div className="textAlani">
          <p>
            Kromun ülkemizde çıkarılması grafikteki gibi ithalatın çok az
            olmasını hatta ihracatı arttırmakta.
          </p>
          <p>Yüksek kar marjı olması ülkemize büyük katkı sağlamakta.</p>
        </div>
      </div>
    </div>
    </>
    
  );
};

export default Tablolar;
