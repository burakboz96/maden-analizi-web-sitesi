import "./uzman.css"

const Uzman = () => {
  return (
    <div>
      uzman sayfası
    </div>
  )
}

export default Uzman
