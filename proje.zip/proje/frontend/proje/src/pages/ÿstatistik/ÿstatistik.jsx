
import { useState } from "react";
import "./istatistik.css";

const İstatistik = () => {
  
  
  
    const [menuVisible,setMenuVisible] = useState(false);
  
  
    const menuDegistir = () => {
        setMenuVisible(!menuVisible)
    }

  
  return (
    <div className="ist-page">
      <header>
        
        <nav className="navigation">
            <a>MADEN İSTATİSTİKLERİ</a>
            
        </nav>
       
    </header>
    <div className="navbar">
        <div className={`menu-icon ${menuVisible ? "active" : ""}`} id="menu-icon" onClick={menuDegistir}>
            <div className="bar"></div>
            <div className="bar"></div>
            <div className="bar"></div>
        </div>
        <ul className={`menu-list ${menuVisible ? "show" : ""}`} id="menu-list">
            <li><a href="/">Anasayfa</a></li>
            <li><a href="https://www.borsaistanbul.com/dosyalar/kmtp/veriler/kmp_au.pdf">Altın İşlemleri</a></li>
            <li><a href="https://www.borsaistanbul.com/dosyalar/kmtp/veriler/kmp_pl.pdf">Platin İşlemleri</a></li>
            <li><a href="https://www.borsaistanbul.com/dosyalar/kmtp/veriler/kmp_pd.pdf">Paladyum İşlemleri</a></li>
            <li><a href="https://www.borsaistanbul.com/dosyalar/kmtp/veriler/kmp_ag.pdf">Gümüş İşlemleri</a></li>
            <li><a href="https://www.borsaistanbul.com/dosyalar/kmtp/veriler/kmo.pdf">Kıymetli Madenler ve ödünç piyasası işlemleri</a></li>
        </ul>
    </div>

    <div className="header">
        <div className="search-bar">
            <input type="text" placeholder="Ara..."/>
            <div className="search-icon"></div>
        </div>
    </div>

    <input type="checkbox" id="sec1"/> 
    <label className="label" htmlFor="sec1">YILLAR İTİBARİYLE RUHSAT MÜRAACAT SAYILARI</label> 
    <div className="content-istatistik"> 
       <img src="./resimler/yillarruhmuracat.png" alt="sec1" /> 
    </div> 

    <input type="checkbox" id="sec2" /> 
    <label className="label" htmlFor="sec2">DEVLET HAKKI BİLGİLERİ</label> 
    <div className="content-istatistik"> 
        <img src="resimler/yildevlethakki.png" alt="sec2" /> 
    </div> 

    <input type="checkbox" id="sec3" /> 
    <label className="label" htmlFor="sec3">MADENCİLİK SEKTÖRÜNÜN GSYH İÇERİSİNDEKİ PAYI</label> 
    <div className="content-istatistik"> 
        <img src="resimler/madcisekgsyhpay.png" alt="sec3" />
    </div> 

    <input type="checkbox" id="sec4" /> 
    <label className="label" htmlFor="sec4">YILLAR İTİBARIYLA TÜRKİYE GENELİNDEKİ RUHSAT SAYILARI </label> 
    <div className="content-istatistik"> 
        <img src="resimler/safTRGenelruhsatsay.png" alt="sec4" /> 
    </div> 

    <input type="checkbox" id="sec5" /> 
    <label className="label" htmlFor="sec5">YILLAR İTİBARİYLE MADENCİLİK SEKTÖRÜ İTHALAT RAKAMLARI </label> 
    <div className="content-istatistik"> 
        <img src="resimler/yilitiithrak.png" alt="sec5" />
    </div> 
    <input type="checkbox" id="sec6" /> 
    <label className="label" htmlFor="sec6">MADEN ÜRETİM DEĞERLERİ </label> 
    <div className="content-istatistik"> 
        <img src="resimler/c.png" alt="sec6" />
    </div> 

    <input type="checkbox" id="sec7" /> 
    <label className="label" htmlFor="sec7">MADENCİLİK İŞ KOLUNDA FAALİYET GÖSTEREN İŞYERİ VE İŞÇİ SAYILARI</label> 
    <div className="content-istatistik"> 
       <img src="resimler/b.png" alt="sec7" /> 
    </div> 
    </div>
  );
};

export default İstatistik;


// document.getElementById('menu-icon').addEventListener('click', function () {
//     var menuList = document.getElementById('menu-list');
//     var menuIcon = document.getElementById('menu-icon');
    
//     menuList.classList.toggle('show');
//     menuIcon.classList.toggle('active');
// });

// document.getElementById('menu-list').addEventListener('click', function () {
//     var menuList = document.getElementById('menu-list');
//     var menuIcon = document.getElementById('menu-icon');
    
//     menuList.classList.remove('show');
//     menuIcon.classList.remove('active');
// });