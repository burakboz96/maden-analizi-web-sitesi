import React, { useEffect } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const MapComponent = () => {
  useEffect(() => {
    // Component mount olduğunda harita oluşturuluyor
    const map = L.map('map').setView([39.9334, 32.8597], 6); // Türkiye'nin merkezi koordinatları

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    // Örnek maden bölgeleri
    const madenBolgeleri = [
      { lat: 41.0082, lng: 28.9784, name: 'İstanbul Maden Bölgesi:   \n  linyit %11,7 \n altın %16,5 \n boksit %3,32 \n gümüş %23,2 \n bakır%13,4 \n platin%1,2' },
      { lat: 37.8716, lng: 32.4840, name: 'Konya Maden Bölgesi   \n linyit %12,1 \n altın %19,1\n boksit %1,32\ngümüş %15,2\nbakır%9,4\nplatin%1,2' },
      { lat: 38.4192, lng: 27.1287, name: 'İzmir Maden Bölgesi   \n linyit %6.4 \n altın %12,1\n boksit %2,92\ngümüş %13,2\nbakır%12,6\nplatin%3,1' },
      { lat: 38.6815, lng: 39.2269, name: 'Elazığ Maden Bölgesi   \n linyit %32,6 \n altın %12,1\n boksit %3,4\ngümüş %15.5\nbakır%30.5\nplatin%1,2' },
      { lat: 37.9136, lng: 40.2177, name: 'Diyarbakır Maden Bölgesi   \n linyit %32,6 \n altın %4,1\n çinko%9,7\ngümüş %1,5\nbakır%36,6\ndemir%11,9' },
    ];

    madenBolgeleri.forEach((maden) => {
      L.marker([maden.lat, maden.lng]).addTo(map)
        .bindPopup('<b>' + maden.name + '</b>');
    });

    // Component unmount olduğunda harita siliniyor
    return () => {
      map.remove();
    };
  }, []); // useEffect sadece bir kere çalışsın diye boş dependency array kullanıldı

  return <div id="map" style={{ height: '100vh' }}></div>;
};

export default MapComponent;
