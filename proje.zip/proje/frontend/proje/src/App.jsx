import { useState } from 'react'
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import MainPage from './pages/Main/MainPage';
import Madenler from './pages/Madenler/Madenler';
import İstatistik from  "./pages/İstatistik/İstatistik"
import Haritalar from './pages/Haritalar/Haritalar';
import Uzman from './pages/Uzman_görüsü/Uzman';
import Tablolar from './pages/Tablolar/Tablolar';

function App() {
  

  return (
    <div>
    <Router>
    <Routes>
      <Route path="/" element={<MainPage />}  />
      <Route path="/madenler" element={<Madenler />}  />
      <Route path="/istatistik" element={<İstatistik />}  />
      <Route path="/haritalar" element={<Haritalar />}  />
      <Route path="/uzman" element={<Uzman />}  />
      <Route path="/tablolar" element={<Tablolar />}  />

    </Routes>
        

    </Router>
    </div>
  )
}

export default App
